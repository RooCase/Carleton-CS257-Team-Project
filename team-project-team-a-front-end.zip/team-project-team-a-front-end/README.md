# team-project-team-a
Team Members:
* Roo Case
* Artem Yushko
* Rowan Hinrichs
* Batmend Batsaikhan

check "documentation" folder for more information and documentation on submissions