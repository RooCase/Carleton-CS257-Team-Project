DROP TABLE IF EXISTS districts;
CREATE TABLE districts (
    districtName TINYTEXT,
    districtType TINYTEXT,
    enrollment MEDIUMINT,
)