TO RUN:
In the parent directory, run "python3 flaskWithCSS.py"

Known issues:
COVID data doesn't properly display on any given school or district.
"Search" feature doesn't yet work.